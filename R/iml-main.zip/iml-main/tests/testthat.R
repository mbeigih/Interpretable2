library(testthat)
library(checkmate)
library(iml)

test_check("iml")
