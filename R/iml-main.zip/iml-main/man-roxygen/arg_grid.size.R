#' @param grid.size The size of the grid for evaluating the predictions
