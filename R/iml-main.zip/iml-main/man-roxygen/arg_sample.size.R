#' @param sample.size The number of instances to be sampled from X. 
