#' @param newdata [data.frame]\cr
#'   Data to predict on.
