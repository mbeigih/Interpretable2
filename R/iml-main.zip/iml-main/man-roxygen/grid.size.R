#' @param grid.size (`numeric(1)` | `numeric(2)`)\cr
#'   The size of the grid for evaluating the predictions.
