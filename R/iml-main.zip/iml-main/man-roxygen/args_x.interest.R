#' @param x.interest data.frame with a single row for the instance to be explained.
