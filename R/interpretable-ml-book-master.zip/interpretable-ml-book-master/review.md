# Review Guidelines


Your review will help improve the book.
This is an open peer-review.
This means anyone can comment here in this issue.


Link to the chapter: LINK
Just in case: link to the Rmd of the chapter: LINK

Please check the chapter for the following points:

- Does the title of the chapter describe the chapter?
- Does the first section make clear what to expect from the rest of the chapter?
- Organization: Does the order of the sections make sense?
- Are the tables, figures and other images good? Is easy to understand what they mean? Is the caption self-explaining?
- Are the main claims of the chapter backed up with good arguments, proofs, examples, references?
- Are all the statements correct?
- Anything else you think might improve this chapter?
- Is some graphic missing that could better explain some concept better ?

For methods chapters:
- Any Disadvantages of Advantages missing?
- 


With your permission, your name will appear 